LootFarmer — targeted localization patch for Changes 50–55

ENGLISH SOURCE: localization/en.po in lootFarmer2.zip
SHA-256: 8212766e4a508781d1567b34f3ac1864f510890e09ff7a0898707dc736fab02f

CONTENTS
- 19 complete locale .po files in localization/ (2,027 message IDs per language)
- change_scope.json: the ONLY 104 IDs included in this localization update
- translation_validation.json: per-file hash and structural validation information

CHANGE SCOPE
- 100 NEW IDs and 4 changed-meaning IDs, 104 per language (1,976 new/changed translations total).
- The 4 changed-meaning IDs were absent from the supplied old locale files; this patch restores them with new translations.
- 25 retired IDs were already absent and are not reintroduced.
- All 1,923 existing non-header entries in each original locale catalog are preserved verbatim.
- Existing file headers were also preserved; older X-LootFarmer-Source metadata was intentionally not rewritten.

MANDATORY INTEGRATION POLICY
1. Claude should compare/review ONLY the 104 IDs in change_scope.json for translation wording and formatting.
2. For all other IDs, enforce an automated equality check against the previously approved files; do not retranslate.
3. Import and validate strictly in 5+5+5+4 locales as listed in change_scope.json.
4. Validate language-specific font/glyph display, placeholders, line wrapping, UI (432x960 and 540x960), live switching, packaging and Android device behavior before activating locales.
5. Do not mark language QA complete on the basis of structural validation alone. No game-runtime or Android validation was run in the translation handoff environment.
6. Keep handoff ZIP outside the Godot localization folder; copy just the .po files needed in each batch.
